// Name: Jacob Luera
package Main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

class FileIO {
    // Read data from the database file
    public static ArrayList<String> readData(String fileName) {
        ArrayList<String> data = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) {
                data.add(line);
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }
    //write data from the database file
    public static void writeData(String fileName, ArrayList<String> data) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
            for (String entry : data) {
                bw.write(entry);
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
