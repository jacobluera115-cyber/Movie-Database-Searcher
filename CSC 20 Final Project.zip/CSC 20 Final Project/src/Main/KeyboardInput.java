// Name: Jacob Luera
package Main;

import java.io.BufferedReader;
import java.io.IOException;


class KeyboardInput {
    private BufferedReader reader;

    public KeyboardInput() {
        reader = new BufferedReader(new java.io.InputStreamReader(System.in));
    }

    public String getInput(String prompt) {
        try {
            System.out.print(prompt);
            return reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    public void close() {
        try {
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}