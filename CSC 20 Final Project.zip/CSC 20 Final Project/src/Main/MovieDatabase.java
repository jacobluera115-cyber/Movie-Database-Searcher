// Name: Jacob Luera
package Main;

import java.util.ArrayList;

class MovieDatabase {
    private ArrayList<MovieEntry> entries;

    public MovieDatabase() {
        entries = new ArrayList<>();
    }

    public void addEntry(MovieEntry entry) {
        entries.add(entry);
    }


    public boolean deleteEntry(String title) {
        // Find the entry by title
        MovieEntry entryToDelete = null;
        for (MovieEntry entry : entries) {
            if (entry.getTitle().equalsIgnoreCase(title)) {
                entryToDelete = entry;
                break;
            }
        }

        if (entryToDelete != null) {
            // Remove the entry from memory
            entries.remove(entryToDelete);

            // Update the database file
            updateDatabaseFile();

            return true; // Entry successfully deleted
        } else {
            return false; // Entry not found
        }
    }

    public void updateDatabaseFile() {
        // Convert entries to string and write back to the file
        ArrayList<String> data = new ArrayList<>();
        for (MovieEntry entry : entries) {
            String entryString = entry.getTitle() + ","
                    + entry.getActor1() + ","
                    + entry.getActor2() + ","
                    + entry.getYear() + ","
                    + entry.getRuntime() + ","
                    + entry.getDirector();
            data.add(entryString);
        }
        FileIO.writeData("db.txt", data);
    }

    public ArrayList<MovieEntry> searchByActor(String actor) {
        ArrayList<MovieEntry> result = new ArrayList<>();
        for (MovieEntry entry : entries) {
            if (entry.getActor1().equalsIgnoreCase(actor) || entry.getActor2().equalsIgnoreCase(actor)) {
                result.add(entry);
            }
        }
        return result;
    }

    public ArrayList<MovieEntry> searchByYear(int year) {
        ArrayList<MovieEntry> result = new ArrayList<>();
        for (MovieEntry entry : entries) {
            if (entry.getYear() == year) {
                result.add(entry);
            }
        }
        return result;
    }

    public ArrayList<MovieEntry> searchByRuntime(int runtime) {
        ArrayList<MovieEntry> result = new ArrayList<>();
        for (MovieEntry entry : entries) {
            if (entry.getRuntime() == runtime) {
                result.add(entry);
            }
        }
        return result;
    }

    public ArrayList<MovieEntry> searchByDirector(String director) {
        ArrayList<MovieEntry> result = new ArrayList<>();
        for (MovieEntry entry : entries) {
            if (entry.getDirector().equalsIgnoreCase(director)) {
                result.add(entry);
            }
        }
        return result;
    }

    public MovieEntry searchByTitle(String title) {
        for (MovieEntry entry : entries) {
            if (entry.getTitle().equalsIgnoreCase(title)) {
                return entry;
            }
        }
        return null;
    }

    public ArrayList<MovieEntry> getAllEntries() {
        return entries;
    }
    
}