// Name: Jacob Luera
package Main;

class MovieEntry {
    private String title;
    private String actor1;
    private String actor2;
    private int year;
    private int runtime;
    private String director;

    public MovieEntry(String title, String actor1, String actor2, int year, int runtime, String director) {
        this.title = title;
        this.actor1 = actor1;
        this.actor2 = actor2;
        this.year = year;
        this.runtime = runtime;
        this.director = director;
    }

    public String getTitle() {
        return title;
    }

    public String getActor1() {
        return actor1;
    }

    public String getActor2() {
        return actor2;
    }

    public int getYear() {
        return year;
    }

    public int getRuntime() {
        return runtime;
    }

    public String getDirector() {
        return director;
    }

    public void print() {
        System.out.println("Title: " + title);
        System.out.println("Actor 1: " + actor1);
        System.out.println("Actor 2: " + actor2);
        System.out.println("Year: " + year);
        System.out.println("Runtime: " + runtime + " minutes");
        System.out.println("Director: " + director);
    }
    @Override
    public String toString() {
        return "Title: " + title + "\n" +
                "Actor 1: " + actor1 + "\n" +
                "Actor 2: " + actor2 + "\n" +
                "Year: " + year + "\n" +
                "Runtime: " + runtime + " minutes\n" +
                "Director: " + director + "\n";
    }
}
