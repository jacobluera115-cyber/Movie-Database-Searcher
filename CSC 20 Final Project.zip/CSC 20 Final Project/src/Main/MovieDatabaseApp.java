// Name: Jacob Luera
package Main;

import java.util.ArrayList;
import Main.KeyboardInput;
import Main.MovieDatabase;
import Main.MovieEntry;

class MovieDatabaseApp {
    public static void main(String[] args) {
        KeyboardInput input = new KeyboardInput();
        MovieDatabase database = new MovieDatabase();
        ArrayList<String> data = FileIO.readData("db.txt");

        // Load existing entries from the database file
        for (String line : data) {
            String[] parts = line.split(",");
            if (parts.length == 6) {
                MovieEntry entry = new MovieEntry(parts[0], parts[1], parts[2], parse(parts[3]), parse(parts[4]), parts[5]);
                database.addEntry(entry);
            }
        }

        boolean quit = false;
        while (!quit) {
            System.out.println("Jacob Luera's Movie management system!");
            System.out.println("1. New Entry");
            System.out.println("2. Search by Actor");
            System.out.println("3. Search by Year");
            System.out.println("4. Search by Runtime");
            System.out.println("5. Search by Director");
            System.out.println("6. Search by Title");
            System.out.println("7. Delete Entry");
            System.out.println("8. Quit");
            System.out.print("Enter command > ");
            try {
                int choice = parse(input.getInput(""));
                switch (choice) {
                case 1:
                    // Add new entry logic
                    String title = input.getInput("Enter title >");
                    String actor1 = input.getInput("Enter actor 1 >");
                    String actor2 = input.getInput("Enter actor 2 >");
                    int year = parse(input.getInput("Enter year >"));
                    int runtime = parse(input.getInput("Enter runtime (minutes) >"));
                    String director = input.getInput("Enter director >");

                    MovieEntry newEntry = new MovieEntry(title, actor1, actor2, year, runtime, director);
                    database.addEntry(newEntry);
                    System.out.println("New entry added successfully.");

                    // Save the updated database to the file
                    database.updateDatabaseFile();
                    break;

                    case 2:
                        // Search by Actor logic
                        String actorToSearch = input.getInput("Enter actor >");
                        ArrayList<MovieEntry> actorSearchResults = database.searchByActor(actorToSearch);
                        if (!actorSearchResults.isEmpty()) {
                            // Display movie titles for the actor
                            System.out.println("Movies featuring " + actorToSearch + ":");
                            for (MovieEntry entry : actorSearchResults) {
                                System.out.println(entry.getTitle());
                            }
                        } else {
                            System.out.println("No titles found for actor " + actorToSearch);
                        }
                        break;
                    case 3:
                        // Search by Year logic
                        int yearToSearch = parse(input.getInput("Enter year >"));
                        ArrayList<MovieEntry> yearSearchResults = database.searchByYear(yearToSearch);
                        if (!yearSearchResults.isEmpty()) {
                            printSearchResults(yearSearchResults);

                        } else {
                            System.out.println("No titles found for the given year.");
                        }
                        break;
                    case 4:
                        // Search by Runtime logic
                        int runtimeToSearch = parse(input.getInput("Enter runtime (minutes) >"));
                        ArrayList<MovieEntry> runtimeSearchResults = database.searchByRuntime(runtimeToSearch);
                        printSearchResults(runtimeSearchResults);
                        break;

                    case 5:
                        // Search by Director logic
                        String directorToSearch = input.getInput("Enter director >");
                        ArrayList<MovieEntry> directorSearchResults = database.searchByDirector(directorToSearch);
                        printSearchResults(directorSearchResults);
                        break;

                    case 6:
                        // Search by Title logic
                        String titleToSearch = input.getInput("Enter title >");
                        MovieEntry titleSearchResult = database.searchByTitle(titleToSearch);
                        if (titleSearchResult != null) {
                            System.out.println(titleSearchResult);
                        } else {
                            System.out.println("No titles found for the given title.");
                        }
                        break;

                    case 7:
                        // Delete Entry logic
                        String titleToDelete = input.getInput("Enter title to delete >");
                        boolean entryDeleted = database.deleteEntry(titleToDelete);
                        if (entryDeleted) {
                            System.out.println("Entry deleted successfully.");
                        } else {
                            System.out.println("Title not found.");
                        }
                        break;

                    case 8:
                        quit = true;
                        break;

                    default:
                        System.out.println("Invalid command. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }

        // Save the updated database to the file
        ArrayList<String> entriesAsString = new ArrayList<>();
        for (MovieEntry entry : database.getAllEntries()) {
            entriesAsString.add(
                entry.getTitle() + ","
                + entry.getActor1() + ","
                + entry.getActor2() + ","
                + entry.getYear() + ","
                + entry.getRuntime() + ","
                + entry.getDirector()
            );
        }
        FileIO.writeData("db.txt", entriesAsString);

        // Close the scanner when done
        input.close();
    }

    private static int parse(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static void printSearchResults(ArrayList<MovieEntry> results) {
        if (!results.isEmpty()) {
            for (MovieEntry entry : results) {
                System.out.println(entry.getTitle());
            }
        } else {
            System.out.println("No matching entries found.");
        }
    }

        }